# WeatherApp
This weather app is by the help of html css and javascript. The design of the app is amazing . The features of the weather app is that when you open the application then it tell the weather of your current position and it can also tell the weather of any particular city. The search button hover effect is also amazing and the code is very easy

One important thing i push the code on github so may be it remove my api key so you have to use your own api key here


![image](https://user-images.githubusercontent.com/64765400/95932711-70d6ce00-0d81-11eb-920d-3927cbf09fa1.png)
![image](https://user-images.githubusercontent.com/64765400/95932723-792f0900-0d81-11eb-90de-1751fbb17116.png)
![image](https://user-images.githubusercontent.com/64765400/95932736-85b36180-0d81-11eb-9b7e-0e35cf20ae9b.png)
